# README
To compile and run the merge_sort and merge_sort_prll.cpp -
1. Open terminal and navigate to the folder containing the files.
2. Type make in the terminal
    ```
    $ make
    ```
3. to run sequential merge_sort
    ``` 
    $ ./merge_sort number_of_threads input_size
    ```
4. To run parallel merge_sort
    ``` 
    $ ./merge_sort_prll number_of_threads input_size
    ```
